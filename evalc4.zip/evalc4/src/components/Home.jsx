export const Home = () => {
    return (
      <div className="homepage">
        Welcome to Laptop service center. Please login to continue
      </div>
    );
  };